package com.example.akosombotour;

import java.util.ArrayList;

public class HistoryModel {
    //declare private data instead of public to ensure the privacy of data field of each class
    private String history;


    public HistoryModel(String history) {
        this.history = history;

    }

    //retrieve user's name
    public String getHistory(){
        return history;
    }



    public static ArrayList<HistoryModel> getUsers() {
        ArrayList<HistoryModel> history = new ArrayList<HistoryModel>();
        history.add(new HistoryModel("Harry"));
        history.add(new HistoryModel("Marla"));
        history.add(new HistoryModel("Sarah"));
        return history;
    }
}